//
//  APDUSender.h
//  APDUSender
//
//  Created by Jakub Mejtský on 29/10/2018.
//  Copyright © 2018 AHEAD iTec, s.r.o. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for APDUSender.
FOUNDATION_EXPORT double APDUSenderVersionNumber;

//! Project version string for APDUSender.
FOUNDATION_EXPORT const unsigned char APDUSenderVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <APDUSender/PublicHeader.h>


